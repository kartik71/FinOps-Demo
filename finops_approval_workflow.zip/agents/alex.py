def run(input_data):
    print("[Alex] Handling user input:", input_data)
    return {"project_id": "P0001"}  # Simulated user prompt