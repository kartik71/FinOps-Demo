def run(input_data):
    return {"summary": "PO validated, budget and compliance passed, variance analyzed."}