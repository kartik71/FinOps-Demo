import streamlit as st
import pandas as pd
import requests
import json
import os
import time
from pathlib import Path

# Set page configuration
st.set_page_config(
    page_title="FinOps Approval Workflow",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for styling
st.markdown("""
<style>
    .persona-box {
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 10px;
    }
    .persona-alex { background-color: #d4f1f9; }
    .persona-sam { background-color: #e1f7d5; }
    .persona-mira { background-color: #fff2cc; }
    .persona-jordan { background-color: #ffe6e6; }
    .persona-sam-decision { background-color: #e1f7d5; }
    .persona-taylor { background-color: #e6e6fa; }
    .persona-alex-summary { background-color: #d4f1f9; }
    .status-badge {
        padding: 5px 10px;
        border-radius: 10px;
        font-weight: bold;
    }
    .status-pending { background-color: #f0f0f0; color: #555; }
    .status-active { background-color: #0288d1; color: white; }
    .status-complete { background-color: #00c853; color: white; }
    .status-error { background-color: #f44336; color: white; }
</style>
""", unsafe_allow_html=True)

# App title and description
st.title("🏢 FinOps Approval Workflow")
st.caption("An end-to-end demo of the approval process across multiple personas")

# Initialize session states
if 'workflow_stage' not in st.session_state:
    st.session_state.workflow_stage = 0  # 0: Not started, 1-7: Stages of workflow

if 'workflow_data' not in st.session_state:
    st.session_state.workflow_data = {}
    
if 'log_messages' not in st.session_state:
    st.session_state.log_messages = []
    
if 'api_response' not in st.session_state:
    st.session_state.api_response = None

# Function to add log messages with timestamps
def add_log(persona, message):
    timestamp = time.strftime("%H:%M:%S")
    st.session_state.log_messages.append({
        "timestamp": timestamp,
        "persona": persona,
        "message": message
    })

# Load sample data
@st.cache_data
def load_data():
    try:
        current_dir = Path(__file__).parent
        data_path = current_dir / 'data.csv'
        return pd.read_csv(data_path)
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return pd.DataFrame({"Project_ID": ["P0001"], "PO_Requested": [5000], "Cost_Center": ["IT"], 
                           "Supplier": ["VendorX"], "Budget_Remaining": [10000], "Variance": [0.2]})

# Sidebar with configuration
with st.sidebar:
    st.header("Configuration")
    default_api_url = os.environ.get("FINOPS_API_URL", "http://localhost:8000/finops-workflow/invoke")
    api_url = st.text_input("API URL", value=default_api_url)
    
    st.header("Demo Settings")
    demo_speed = st.slider("Demo Speed", 0.5, 3.0, 1.5, 0.1, 
                          help="Controls how fast the demo progresses (higher is faster)")
    
    st.header("Persona Information")
    st.markdown("""
    - **Alex** - User Interface (Request Entry)
    - **Sam** - Data Retrieval Specialist
    - **Mira** - Budget Analyst
    - **Jordan** - Compliance Officer
    - **Sam Decision** - Approval Manager
    - **Taylor** - Financial Analyst
    - **Alex Summary** - Workflow Coordinator
    """)
    
    # Reset button
    if st.button("Reset Demo"):
        st.session_state.workflow_stage = 0
        st.session_state.workflow_data = {}
        st.session_state.log_messages = []
        st.session_state.api_response = None
        st.experimental_rerun()

# Load the data
df = load_data()

# Main interface with two columns
col1, col2 = st.columns([3, 2])

# Left column - Project selection and workflow visualization
with col1:
    # Project selection section
    st.header("Project Selection")
    
    project_col1, project_col2 = st.columns([3, 2])
    
    with project_col1:
        selected_project = st.selectbox(
            "Select a project:",
            options=df["Project_ID"].unique(),
            index=0,
            disabled=st.session_state.workflow_stage > 0
        )
        
        if selected_project:
            project_data = df[df["Project_ID"] == selected_project].iloc[0]
            st.dataframe({
                "Attribute": ["Project ID", "PO Amount", "Cost Center", "Supplier", "Budget Remaining", "Variance"],
                "Value": [
                    project_data["Project_ID"],
                    f"${project_data['PO_Requested']:,.2f}",
                    project_data["Cost_Center"],
                    project_data["Supplier"],
                    f"${project_data['Budget_Remaining']:,.2f}",
                    project_data["Variance"]
                ]
            }, hide_index=True)
    
    with project_col2:
        st.write("")
        st.write("")
        start_button = st.button(
            "Start Approval Process", 
            type="primary",
            disabled=st.session_state.workflow_stage > 0,
            use_container_width=True
        )
        
        st.markdown("### Current Status")
        
        if st.session_state.workflow_stage == 0:
            st.info("Waiting to start workflow")
        elif st.session_state.workflow_stage < 7:
            st.info(f"Processing step {st.session_state.workflow_stage} of 7")
        else:
            if st.session_state.api_response and st.session_state.api_response.get("approved", False):
                st.success("Workflow complete - PO APPROVED")
            else:
                st.error("Workflow complete - PO REJECTED")
    
    # Start the workflow when button is clicked
    if start_button:
        st.session_state.workflow_stage = 1
        add_log("System", f"Starting approval workflow for project {selected_project}")
        
        # Call the API to get real data
        try:
            with st.spinner("Processing approval workflow..."):
                # Make API call to the backend
                payload = {"project_id": selected_project}
                response = requests.post(api_url, json=payload)
                
                if response.status_code == 200:
                    st.session_state.api_response = response.json()
                    add_log("System", "API call successful")
                else:
                    add_log("System", f"API Error: {response.status_code} - {response.text}")
        except Exception as e:
            add_log("System", f"Error connecting to API: {str(e)}")
    
    # Workflow visualization
    st.markdown("### Workflow Visualization")
    
    # Display personas with their current status
    def persona_status(persona_name, stage_number):
        if st.session_state.workflow_stage == 0:
            return "status-pending", "Pending"
        elif st.session_state.workflow_stage == stage_number:
            return "status-active", "Active"
        elif st.session_state.workflow_stage > stage_number:
            return "status-complete", "Complete"
        else:
            return "status-pending", "Pending"
    
    # Auto-advance the workflow for the demo
    if 1 <= st.session_state.workflow_stage < 7:
        # This will be executed once per page refresh
        time.sleep(3.0 / demo_speed)  # Speed controlled by demo_speed
        st.session_state.workflow_stage += 1
        st.experimental_rerun()
    
    # Create the workflow diagram with personas
    persona_cols = st.columns(7)
    
    # Alex - Entry Point
    with persona_cols[0]:
        status_class, status_text = persona_status("Alex", 1)
        st.markdown(f"""
        <div class="persona-box persona-alex">
            <h4>Alex</h4>
            <p>Entry Point</p>
            <span class="status-badge {status_class}">{status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.workflow_stage >= 1:
            add_log("Alex", f"Received request for project {selected_project}")
    
    # Sam - Data Retrieval
    with persona_cols[1]:
        status_class, status_text = persona_status("Sam", 2)
        st.markdown(f"""
        <div class="persona-box persona-sam">
            <h4>Sam</h4>
            <p>Data Retrieval</p>
            <span class="status-badge {status_class}">{status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.workflow_stage >= 2 and st.session_state.api_response:
            add_log("Sam", f"Retrieved project data: PO Amount ${st.session_state.api_response.get('po_amount', 'N/A')}, Supplier: {st.session_state.api_response.get('supplier', 'N/A')}")
    
    # Mira - Budget Check
    with persona_cols[2]:
        status_class, status_text = persona_status("Mira", 3)
        st.markdown(f"""
        <div class="persona-box persona-mira">
            <h4>Mira</h4>
            <p>Budget Check</p>
            <span class="status-badge {status_class}">{status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.workflow_stage >= 3 and st.session_state.api_response:
            budget_ok = st.session_state.api_response.get('budget_ok', False)
            add_log("Mira", f"Budget check: {'PASSED' if budget_ok else 'FAILED'}")
    
    # Jordan - Compliance
    with persona_cols[3]:
        status_class, status_text = persona_status("Jordan", 4)
        st.markdown(f"""
        <div class="persona-box persona-jordan">
            <h4>Jordan</h4>
            <p>Compliance</p>
            <span class="status-badge {status_class}">{status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.workflow_stage >= 4 and st.session_state.api_response:
            compliance_ok = st.session_state.api_response.get('compliance_ok', False)
            add_log("Jordan", f"Compliance check: {'PASSED' if compliance_ok else 'FAILED'}")
    
    # Sam Decision - Approval
    with persona_cols[4]:
        status_class, status_text = persona_status("Sam Decision", 5)
        st.markdown(f"""
        <div class="persona-box persona-sam-decision">
            <h4>Sam Decision</h4>
            <p>Approval</p>
            <span class="status-badge {status_class}">{status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.workflow_stage >= 5 and st.session_state.api_response:
            approved = st.session_state.api_response.get('approved', False)
            reason = st.session_state.api_response.get('reason', 'No specific reason')
            add_log("Sam Decision", f"Decision: {'APPROVED' if approved else f'REJECTED - {reason}'}")
    
    # Taylor - Variance
    with persona_cols[5]:
        status_class, status_text = persona_status("Taylor", 6)
        st.markdown(f"""
        <div class="persona-box persona-taylor">
            <h4>Taylor</h4>
            <p>Variance Analysis</p>
            <span class="status-badge {status_class}">{status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.workflow_stage >= 6 and st.session_state.api_response:
            variance = st.session_state.api_response.get('variance', 'N/A')
            add_log("Taylor", f"Variance analysis: {variance}")
    
    # Alex Summary - Final
    with persona_cols[6]:
        status_class, status_text = persona_status("Alex Summary", 7)
        st.markdown(f"""
        <div class="persona-box persona-alex-summary">
            <h4>Alex Summary</h4>
            <p>Final Summary</p>
            <span class="status-badge {status_class}">{status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.workflow_stage >= 7 and st.session_state.api_response:
            summary = st.session_state.api_response.get('summary', 'Process complete')
            add_log("Alex Summary", f"Final summary: {summary}")

    # Display final results when complete
    if st.session_state.workflow_stage >= 7 and st.session_state.api_response:
        st.markdown("---")
        st.header("Approval Results")
        
        # Display approval status with appropriate styling
        if st.session_state.api_response.get("approved", False):
            st.success("### ✅ PURCHASE ORDER APPROVED")
        else:
            st.error(f"### ❌ PURCHASE ORDER REJECTED: {st.session_state.api_response.get('reason', 'No reason provided')}")
        
        # Show key metrics
        metrics_cols = st.columns(4)
        with metrics_cols[0]:
            st.metric("Project ID", st.session_state.api_response.get('project_id', 'N/A'))
        with metrics_cols[1]:
            st.metric("PO Amount", f"${st.session_state.api_response.get('po_amount', 0):,.2f}")
        with metrics_cols[2]:
            st.metric("Budget Remaining", f"${st.session_state.api_response.get('budget_remaining', 0):,.2f}")
        with metrics_cols[3]:
            st.metric("Variance", f"{st.session_state.api_response.get('variance', 'N/A')}")
        
        # Display summary
        st.info(f"**Summary:** {st.session_state.api_response.get('summary', 'N/A')}")

# Right column - Real-time logs and technical details
with col2:
    st.header("Real-time Activity Log")
    
    # Display log messages
    for log in reversed(st.session_state.log_messages):
        persona_color = {
            "System": "#6c757d",
            "Alex": "#0288d1",
            "Sam": "#388e3c",
            "Mira": "#fbc02d",
            "Jordan": "#d32f2f",
            "Sam Decision": "#388e3c",
            "Taylor": "#7b1fa2",
            "Alex Summary": "#0288d1"
        }.get(log["persona"], "#6c757d")
        
        st.markdown(f"""<div style='margin-bottom: 8px;'>
            <span style='color: #888; font-size: 0.8em;'>{log['timestamp']}</span> - 
            <span style='color: {persona_color}; font-weight: bold;'>{log['persona']}</span>: 
            {log['message']}
        </div>""", unsafe_allow_html=True)
    
    # Technical details section
    if st.session_state.api_response:
        st.markdown("---")
        st.header("Technical Details")
        with st.expander("View API Response"):
            st.json(st.session_state.api_response)

# Footer
st.markdown("---")
st.caption("FinOps Approval Workflow - Powered by LangGraph & Streamlit")

