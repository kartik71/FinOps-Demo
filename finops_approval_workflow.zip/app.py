from fastapi import FastAPI
from langserve import add_routes
from main import graph

# Create a FastAPI app
app = FastAPI(
    title="FinOps Approval Workflow",
    description="An agentic LangGraph application for financial operations approval workflows",
    version="1.0",
)

# Add routes for the graph
add_routes(
    app,
    graph,
    path="/finops-workflow",
)

# Add a health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy"}

# Add documentation to the root endpoint
@app.get("/")
async def root():
    return {
        "message": "Welcome to the FinOps Approval Workflow API",
        "docs_url": "/docs",
        "health_check": "/health",
        "api_endpoint": "/finops-workflow"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
